$Header: /cvsroot/zipdiff/zipdiff/readme.txt,v 1.1 2004/04/13 02:59:46 sullis Exp $ 

The zipdiff project

http://zipdiff.sourceforge.net/

License:  see LICENSE.txt
